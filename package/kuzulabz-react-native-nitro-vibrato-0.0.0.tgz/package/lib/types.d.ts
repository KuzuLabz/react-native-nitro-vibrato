export interface Token {
    surface: string;
    lexType: string;
    features: string[];
    wordId: number;
    leftId: number;
    rightId: number;
    wordCost: number;
    totalCost: number;
}
export interface TextdictPaths {
    lex: string;
    matrix: string;
    char: string;
    unk: string;
}
export interface TextdictBytes {
    lex: Uint8Array<ArrayBufferLike>;
    matrix: Uint8Array<ArrayBufferLike>;
    char: Uint8Array<ArrayBufferLike>;
    unk: Uint8Array<ArrayBufferLike>;
}
export interface InitializeOptions {
    ignoreSpace?: boolean;
    maxGroupingLength?: number;
}
