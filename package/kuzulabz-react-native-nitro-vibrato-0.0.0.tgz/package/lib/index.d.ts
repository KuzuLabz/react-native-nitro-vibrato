import type { InitializeOptions, TextdictBytes, TextdictPaths, Token } from './types';
declare class VibratoClass {
    private _native;
    isInitialized: boolean;
    /**
     * Creates a Vibrato instance.
     *
     * @param dic A local path uri or an ArrayBuffer
     *
     * @param options Optional dictionary settings. To get the same results as Mecab, use the {@linkcode MecabPreset}.
     *
     * @platforms Android, iOS
     *
     * **Path URI is not supported on web**
     */
    initialize(dic: string | Uint8Array<ArrayBufferLike>, userDict?: string | Uint8Array<ArrayBufferLike>, options?: InitializeOptions): Promise<void>;
    initializeFromTextDic(files: TextdictBytes | TextdictPaths, userDict?: string | Uint8Array<ArrayBufferLike>, options?: InitializeOptions): Promise<void>;
    compileDictionary(files: TextdictBytes | TextdictPaths): Promise<Uint8Array | null>;
    tokenize(text: string): Promise<Token[] | null>;
    wakati(text: string): Promise<string[] | null>;
    destroy(): void;
}
/**
 * Initialize WASM asynchronously
 *
 * @platforms web
 */
export declare const initWasmAsync: () => Promise<void>;
/**
 * Initialize WASM synchronously
 *
 * @platforms web
 */
export declare const initWasmSync: () => void;
export declare const Vibrato: VibratoClass;
export type { InitializeOptions, TextdictBytes, TextdictPaths, Token } from './types';
export { MecabPreset } from './constants';
