import type { InitializeOptions } from "./types";
export declare const MecabPreset: InitializeOptions;
