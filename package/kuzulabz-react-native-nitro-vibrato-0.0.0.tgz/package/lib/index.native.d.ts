import type { InitializeOptions, TextdictBytes, TextdictPaths, Token } from './types';
declare class VibratoClass {
    private native;
    /**
     * Creates a Vibrato instance.
     *
     * @param dic A local path uri or an ArrayBuffer
     *
     * @param options Optional dictionary settings. To get the same results as Mecab, use the {@linkcode MecabPreset}.
     *
     * @platforms Android, iOS
     *
     * **Path URI is not supported on web**
     */
    initialize(dic: string | ArrayBuffer, options?: InitializeOptions): Promise<void>;
    /**
     * Creates a Vibrato instance from multiple dic files.
     *
     * @param files A {@linkcode TextdictPaths} object of local path URIs or a {@linkcode TextdictBytes} object of Arraybuffers.
     *
     * @param options Optional dictionary settings. To get the same results as Mecab, use the {@linkcode MecabPreset}.
     *
     * @platforms Android, iOS
     *
     * **Path URI is not supported on web**
     *
     * @example
     * ```
     * initializeFromTextDic({
     *  lex: lexUri,
        matrix: matrixUri,
        char: charUri,
        unk: unkUri
     * });
     * ```
     */
    initializeFromTextDic(files: TextdictBytes | TextdictPaths, options?: InitializeOptions): Promise<void>;
    tokenize(text: string): Promise<Token[] | null>;
    wakati(text: string): Promise<string[] | null>;
    compileDictionary(files: TextdictBytes | TextdictPaths): Promise<Uint8Array | null>;
    destroy(): void;
}
export declare const initWasmAsync: () => Promise<void>;
export declare const initWasmSync: () => void;
export declare const Vibrato: VibratoClass;
export type { InitializeOptions, TextdictBytes, TextdictPaths, Token } from './types';
export { MecabPreset } from './constants';
